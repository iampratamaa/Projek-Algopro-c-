#include <iostream>

using namespace std;

int main()
{
    int x=-64;
    x=x<<2;
    cout << "x << 2 : " <<x<< endl;
    return 0;
}
