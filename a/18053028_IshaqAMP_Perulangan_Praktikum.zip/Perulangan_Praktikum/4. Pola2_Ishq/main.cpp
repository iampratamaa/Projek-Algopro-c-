#include <iostream>
using namespace std;
int main(){
int a,b;
for (a=10;a>=1;a--)
{
    for (b=a;b>=1;b--)
    {
        cout <<" "<<b;
    }
cout<<endl;
}
return 0;
}
